# Social Engineering Attacks

## 1. Introduction

Social engineering is the manipulation of people into performing actions or revealing
information that benefits an attacker. It is particularly effective because it targets human
decision-making rather than relying only on technical vulnerabilities.

## 2. Phishing

Phishing uses deceptive messages or websites to persuade a victim to reveal information,
open content, or take an unsafe action.

### Common Types

- Spear phishing — targeted phishing against a specific person or group.
- Whaling — phishing aimed at senior or high-value targets.
- Vishing — phishing performed through voice communication.
- Smishing — phishing performed through SMS or similar messaging.

### Prevention

1. Use multi-factor authentication.
2. Verify unexpected requests independently.
3. Inspect links and sender details carefully.
4. Provide regular security-awareness training.

### Case Study

`[INSERT VERIFIED REAL-WORLD CASE AND SOURCE]`

## 3. Pretexting

Pretexting involves creating a believable false scenario to persuade a target to disclose
information or perform an action.

### Prevention

1. Verify identity and requests using an independent channel.
2. Follow formal approval procedures for sensitive actions.
3. Train employees to recognize unusual requests.

### Case Study

`[INSERT VERIFIED CASE AND SOURCE]`

## 4. Baiting

Baiting uses an attractive or useful-looking item as the lure. Examples can include fake
downloads or removable media presented as something interesting.

### Prevention

1. Restrict use of unknown removable media.
2. Use endpoint protection and application controls.
3. Train users not to install or open untrusted content.

### Case Study

`[INSERT VERIFIED CASE AND SOURCE]`

## 5. Quid Pro Quo

Quid pro quo attacks offer a supposed benefit or service in exchange for information or an
action.

### Prevention

- Verify support requests.
- Never disclose credentials to an unsolicited caller.
- Use official support channels.

## 6. Comparison Table

| Attack Type | Primary Target | Psychological Lever | Best Countermeasure |
|---|---|---|---|
| Phishing | Users | Urgency/trust | MFA + awareness |
| Pretexting | Employees | Authority/trust | Independent verification |
| Baiting | Users | Curiosity/reward | Device and download controls |
| Quid Pro Quo | Users | Help/reward | Verification and policy |

## 7. Employee Security Awareness Checklist

1. Verify unexpected requests.
2. Report suspicious messages.
3. Use MFA.
4. Never share passwords or authentication codes.
5. Use only approved software, links, and removable media.

## 8. References

- CISA — https://www.cisa.gov/
- SANS Reading Room — https://www.sans.org/white-papers/
- NIST — https://www.nist.gov/
- MITRE ATT&CK — https://attack.mitre.org/

Add at least one verified source for each selected case study before final submission.
