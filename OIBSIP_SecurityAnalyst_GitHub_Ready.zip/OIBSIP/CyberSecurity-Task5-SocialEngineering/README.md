# Task 5 — Research Report: Social Engineering Attacks

The main report is stored in `social_engineering_report.md`.

The report covers phishing, pretexting, baiting, quid pro quo, comparison, organizational
recommendations, and references.
