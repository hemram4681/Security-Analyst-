# Task 2 — Basic Firewall Configuration with UFW

## Objective

Configure a basic Linux firewall using UFW and document the purpose of each rule.

## Tools

- UFW
- Ubuntu or Kali Linux virtual machine

## Lab Scope

This configuration is intended for my own Linux VM.

## Configuration Script

The supplied `ufw_configuration.sh` demonstrates the requested firewall rules.
Review every rule before executing it on your lab machine.

## Verification

After applying the rules, verify the configuration with:

```bash
sudo ufw status verbose
```

Take a screenshot and place it in `screenshots/`.

## Rule Analysis

| Rule | Purpose | Reason |
|---|---|---|
| Allow SSH | Permit authorized SSH administration | Required for remote administration when SSH is intentionally used |
| Deny HTTP | Block inbound HTTP | Demonstrates restricting an unwanted service |
| Allow HTTPS | Permit secure web traffic when required | Supports HTTPS services |
| Additional rule | `[DOCUMENT YOUR ACTUAL RULE]` | `[REASON]` |

## Testing

Document how you tested that the denied traffic was blocked.
Use only your own VM/lab environment.

## Conclusion

A firewall reduces unnecessary network exposure by applying explicit traffic rules.
Rules should follow least privilege and should be reviewed regularly.
