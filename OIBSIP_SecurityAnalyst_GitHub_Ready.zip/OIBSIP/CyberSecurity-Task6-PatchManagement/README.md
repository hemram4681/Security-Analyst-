# Task 6 — Research Report: The Importance of Patch Management

Main report:
`patch_management_report.md`

Before final submission, add verified citations for real-world examples and any statistics
used in the report.
