# Task 1 — Basic Network Scanning with Nmap

## Objective

Perform a basic security-oriented network scan against an authorized local machine or virtual
machine, identify open ports and services, and document the security implications.

## Tools

- Nmap
- Linux terminal or Windows PowerShell
- Local virtual machine such as Kali Linux or Ubuntu

## Lab Scope

Target: `[REPLACE WITH YOUR LOCAL VM IP]`

Only use an IP address belonging to your own authorized lab.

## Workflow

1. Install Nmap if required.
2. Identify the local lab target.
3. Perform a basic scan.
4. Perform service-version detection.
5. Perform OS detection where supported.
6. Record open ports and services.
7. Assess each discovered service for risk.
8. Save the output and screenshots.

## Example Commands

Replace the target placeholder with your authorized local VM address.

```bash
nmap [TARGET_IP]
nmap -sV [TARGET_IP]
nmap -O [TARGET_IP]
```

## Results

See `nmap_scan_results.txt`.

## Evidence

Add terminal screenshots to `screenshots/`.

## Security Analysis

For every open port, document:

| Port | Service | Purpose | Security Risk | Recommendation |
|---|---|---|---|---|
| `[port]` | `[service]` | `[purpose]` | `[risk]` | `[recommendation]` |

## Conclusion

Network scanning provides visibility into exposed services. Services that are not required
should be disabled or restricted, and required services should be kept updated and protected
with appropriate access controls.

## Ethical Use

Nmap must only be used against systems for which the tester has permission.
