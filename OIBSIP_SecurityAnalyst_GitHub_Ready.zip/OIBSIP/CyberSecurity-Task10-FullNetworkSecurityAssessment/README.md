# Task 10 — Full Network Security Assessment

## Required Files

- `network_security_assessment.md`
- `nmap_results.txt`
- `wireshark_capture.pcap`

## Assessment Phases

1. Reconnaissance with Nmap
2. Traffic analysis with Wireshark
3. Nikto web-server assessment where applicable
4. Findings register
5. Executive summary
6. Technical findings
7. Remediation roadmap

## Important

The repository contains templates for evidence-dependent results. Replace every placeholder
with the actual results from your authorized local test environment before submission.
