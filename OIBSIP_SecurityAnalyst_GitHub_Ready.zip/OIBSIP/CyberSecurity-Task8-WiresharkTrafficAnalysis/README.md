# Task 8 — Capture Network Traffic with Wireshark

## Objective

Capture traffic from an authorized local interface, apply protocol filters, analyze a TCP
three-way handshake, and document the security observations.

## Safety

Capture only traffic on a network or interface that I own or administer or for which I have
explicit authorization. Do not capture traffic on public Wi-Fi or another person's network.

## Workflow

1. Install Wireshark.
2. Select the authorized local interface.
3. Capture approximately two minutes of traffic.
4. Apply the required display filters.
5. Analyze a TCP three-way handshake.
6. Save the authorized capture as `wireshark_capture.pcap`.
7. Document observations.

## Display Filters

```text
http
dns
tcp
```

## TCP Three-Way Handshake

Document:

1. SYN
2. SYN-ACK
3. ACK

Add an annotated screenshot.

## Unencrypted Traffic

If an authorized local HTTP request is visible, document what information is exposed and
explain why plaintext HTTP is unsafe.

Do not include private credentials or another person's information in the repository.

## Why HTTPS Helps

HTTPS uses TLS to provide confidentiality and integrity for application traffic between
the client and server, reducing the risk of passive eavesdropping and tampering.

## Glossary

- Packet: a unit of data transmitted across a network.
- Protocol: a set of communication rules.
- Port: a logical endpoint used by network services.
- Payload: the data carried by a packet.
- Handshake: an exchange used to establish communication parameters.

## Evidence

Add screenshots and `wireshark_capture.pcap` generated from your authorized lab traffic.
