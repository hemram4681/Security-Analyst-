# Task 9 — Advanced SQL Injection Assessment on DVWA

## Objective

Extend the local DVWA SQL Injection study into a structured security assessment using an
authorized DVWA instance.

## Safety

This task must remain inside a local DVWA lab that I own or have explicit authorization to
test. Do not use offensive tools or injection techniques against real systems.

## Environment

- DVWA
- Medium security level for the lab
- Optional Burp Suite
- Optional sqlmap for the authorized local lab

## Assessment Areas

Document the results of the authorized lab exercise for:

- Authentication-bypass testing
- Database/table enumeration testing
- Column enumeration testing
- HTTP request/response inspection
- Comparison of manual observations and automated-tool output, if used

Do not fabricate outputs.

## Burp Suite Evidence

If used in the local lab, include a screenshot showing the relevant request/response.

## Remediation

### Python — Parameterized Query

```python
import sqlite3

connection = sqlite3.connect("example.db")
cursor = connection.cursor()

username = input("Username: ")

cursor.execute(
    "SELECT id, username FROM users WHERE username = ?",
    (username,)
)

rows = cursor.fetchall()
print(rows)
```

### PHP — Parameterized Query

```php
$stmt = $pdo->prepare(
    "SELECT id, username FROM users WHERE username = :username"
);

$stmt->execute([
    ':username' => $username
]);

$rows = $stmt->fetchAll();
```

The important security principle is that user input is bound as data rather than being
concatenated into SQL syntax.

## Executive Summary

The assessment demonstrates why SQL Injection is a serious application-security issue.
A vulnerable application can allow user-controlled input to influence database queries.
The primary remediation is parameterized database access, supported by least-privilege
database permissions, secure error handling, and security testing.

## Evidence

Place screenshots and locally generated output in `screenshots/`.
