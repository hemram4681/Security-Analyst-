# Task 4 — Research Report: Common Network Security Threats

The main report is stored in `network_security_threats_report.md`.

The report covers:
- DoS/DDoS
- MITM
- IP Spoofing
- DNS Poisoning/Spoofing
- Mitigation strategies
- Comparison table
- Conclusion
- References

Before submission, replace the real-world example placeholders with verified incidents and
citations from credible sources.
