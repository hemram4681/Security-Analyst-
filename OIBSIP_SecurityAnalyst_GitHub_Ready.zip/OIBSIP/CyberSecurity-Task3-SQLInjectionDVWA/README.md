# Task 3 — SQL Injection on DVWA (Local Lab)

## Objective

Study and demonstrate the SQL Injection vulnerability using DVWA running locally at the
required low-security setting, then explain the cause, impact, and prevention.

## Safety

This task is strictly for a locally installed DVWA instance that I own or am explicitly
authorized to test. Do not use these techniques against real websites or services.

## Environment

- DVWA
- XAMPP/LAMP
- Local web browser
- Optional: Burp Suite for observing the local request

## Lab Setup

1. Install DVWA in a local lab environment.
2. Configure the local web server and database.
3. Set the DVWA security level to Low.
4. Open the SQL Injection module.
5. Record the behavior of the application using authorized test inputs.
6. Capture screenshots of the local lab results.
7. Record observations in `sql_injection_notes.md`.

## What SQL Injection Is

SQL Injection occurs when untrusted input is incorporated into a database query without
adequate separation between data and SQL instructions. An attacker may then influence the
meaning of the query.

## Why It Happens

A vulnerable application may construct SQL statements by directly concatenating user input.
This can allow specially crafted input to change the intended query logic.

## Impact

Depending on the application and database permissions, SQL Injection can expose, modify,
or delete data and may affect application authentication.

## Prevention

Developers should use parameterized queries or prepared statements, apply least-privilege
database permissions, validate input where appropriate, and avoid exposing database errors
to users.

## Evidence

Add screenshots from the local DVWA lab to `screenshots/`.

## Important

Do not invent output or screenshots. Replace the placeholders in the notes with the actual
results from the authorized local DVWA instance.
